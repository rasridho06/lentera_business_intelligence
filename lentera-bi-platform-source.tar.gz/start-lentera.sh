#!/bin/bash
cd /home/z/my-project
export DATABASE_URL="file:/home/z/my-project/db/custom.db"
while true; do
  PORT=3000 HOST=0.0.0.0 bun run bun-api-server.ts 2>&1
  echo "[$(date)] Server died, restarting in 3s..."
  sleep 3
done
