#!/bin/bash
cd /home/z/my-project
export DATABASE_URL="file:/home/z/my-project/db/custom.db"

# Start API server on 3001 - keep restarting
(while true; do
  PORT=3001 HOST=0.0.0.0 bun run bun-api-server.ts 2>&1
  echo "[$(date)] API server exited, restarting in 2s..." >> /home/z/my-project/server-keep.log
  sleep 2
done) &

# Wait for API
for i in $(seq 1 30); do
  curl -sf http://127.0.0.1:3001/api >/dev/null 2>&1 && break
  sleep 1
done

# Start proxy server on 3000 - keep restarting
(while true; do
  PORT=3000 HOST=0.0.0.0 bun run custom-server.ts 2>&1
  echo "[$(date)] Main server exited, restarting in 2s..." >> /home/z/my-project/server-keep.log
  sleep 2
done) &

# Keep this script alive
wait
