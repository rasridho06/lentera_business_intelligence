#!/bin/bash
# Lentera BI Platform - Keep-alive script
# Starts both API server and static+proxy server
# Auto-restarts on crash

cd /home/z/my-project
export DATABASE_URL="file:/home/z/my-project/db/custom.db"

echo "Starting Lentera BI Platform keep-alive..."

# Start API server with auto-restart
(while true; do
  PORT=3001 HOST=0.0.0.0 bun run bun-api-server.ts 2>&1
  echo "[API] Server died at $(date), restarting in 3s..."
  sleep 3
done) &

# Wait for API to be ready
for i in $(seq 1 30); do
  if curl -sf http://localhost:3001/api > /dev/null 2>&1; then
    echo "API server ready"
    break
  fi
  sleep 1
done

# Start main server with auto-restart
(while true; do
  PORT=3000 HOST=0.0.0.0 bun run custom-server.ts 2>&1
  echo "[Main] Server died at $(date), restarting in 3s..."
  sleep 3
done) &

echo "Both servers running. Press Ctrl+C to stop."
wait
